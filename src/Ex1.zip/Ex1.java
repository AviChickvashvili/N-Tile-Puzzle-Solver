


public class Ex1  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadText rt = new ReadText("input.txt");
		rt.printText();
		
		
//		rt.file="input2.txt";
//		rt.printText();
//		rt.file="output.txt";
//		rt.printText();
//		rt.file="output2.txt";
//		rt.printText();
		
		

	}
}

